package com.occapp.newsdigest.activities.detail;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.occapp.newsdigest.R;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}
